public class Msg {
    private byte info;
	
    public Msg(){
		info = 0;
	}
    
	public void setInfo(byte b){
		info = b;
	}
    
	public byte getInfo(){
		return info;
	}
}



