public class Storage {
    private Msg msg;
    private byte stored;
    
	public Storage(){
		msg = new Msg();
		stored = 0;
    }
	
    public void setStored(byte b){
		stored = b;
	}
    
	public byte getStored(){
		return stored;
	}
    
	public void recvMsg(Msg m){
		byte recv = m.getInfo();
		this.msg.setInfo(recv);
    }
    
	public void storeMsg(){
		byte b = this.msg.getInfo();
		setStored(b);
    }
}
